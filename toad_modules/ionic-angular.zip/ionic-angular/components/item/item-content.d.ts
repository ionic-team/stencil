/**
 * @hidden
 */
export declare class ItemContent {
}
