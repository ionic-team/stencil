import { ModuleWithProviders } from '@angular/core';
/** @hidden */
export declare class ClickBlockModule {
    static forRoot(): ModuleWithProviders;
}
