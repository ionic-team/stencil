import { ModuleWithProviders } from '@angular/core';
/** @hidden */
export declare class IconModule {
    static forRoot(): ModuleWithProviders;
}
