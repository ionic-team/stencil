import { ModuleWithProviders } from '@angular/core';
/** @hidden */
export declare class DateTimeModule {
    static forRoot(): ModuleWithProviders;
}
