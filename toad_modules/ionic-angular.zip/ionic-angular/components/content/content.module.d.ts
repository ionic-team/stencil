import { ModuleWithProviders } from '@angular/core';
/** @hidden */
export declare class ContentModule {
    static forRoot(): ModuleWithProviders;
}
