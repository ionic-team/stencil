export var /** @type {?} */ PORTAL_DEFAULT = 1;
export var /** @type {?} */ PORTAL_MODAL = 2;
export var /** @type {?} */ PORTAL_LOADING = 3;
export var /** @type {?} */ PORTAL_TOAST = 4;
//# sourceMappingURL=app-constants.js.map