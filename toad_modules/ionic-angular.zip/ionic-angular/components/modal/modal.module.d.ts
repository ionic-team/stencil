import { ModuleWithProviders } from '@angular/core';
/** @hidden */
export declare class ModalModule {
    static forRoot(): ModuleWithProviders;
}
