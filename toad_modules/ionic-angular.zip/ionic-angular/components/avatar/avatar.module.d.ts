import { ModuleWithProviders } from '@angular/core';
/** @hidden */
export declare class AvatarModule {
    static forRoot(): ModuleWithProviders;
}
