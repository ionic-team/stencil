import { ModuleWithProviders } from '@angular/core';
/** @hidden */
export declare class NavModule {
    static forRoot(): ModuleWithProviders;
}
