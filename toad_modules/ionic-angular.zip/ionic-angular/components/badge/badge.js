var Badge = (function () {
    function Badge() {
    }
    return Badge;
}());
exports.Badge = Badge;