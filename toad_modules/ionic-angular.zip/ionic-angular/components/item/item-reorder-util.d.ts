/**
 * @hidden
 */
export declare function indexForItem(element: any): number;
/**
 * @hidden
 */
export declare function reorderListForItem(element: any): any;
/**
 * @hidden
 */
export declare function findReorderItem(node: any, listNode: any): HTMLElement;
