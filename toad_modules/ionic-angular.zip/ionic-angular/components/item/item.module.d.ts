import { ModuleWithProviders } from '@angular/core';
/** @hidden */
export declare class ItemModule {
    static forRoot(): ModuleWithProviders;
}
