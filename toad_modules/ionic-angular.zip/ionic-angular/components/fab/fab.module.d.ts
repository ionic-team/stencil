import { ModuleWithProviders } from '@angular/core';
/** @hidden */
export declare class FabModule {
    static forRoot(): ModuleWithProviders;
}
