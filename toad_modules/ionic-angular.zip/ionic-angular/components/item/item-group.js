import { Directive } from '@angular/core';
/**
 * @hidden
 */
var ItemGroup = (function () {
    function ItemGroup() {
    }
    return ItemGroup;
}());
export { ItemGroup };
ItemGroup.decorators = [
    { type: Directive, args: [{
                selector: 'ion-item-group'
            },] },
];
/**
 * @nocollapse
 */
ItemGroup.ctorParameters = function () { return []; };
function ItemGroup_tsickle_Closure_declarations() {
    /** @type {?} */
    ItemGroup.decorators;
    /**
     * @nocollapse
     * @type {?}
     */
    ItemGroup.ctorParameters;
}
//# sourceMappingURL=item-group.js.map