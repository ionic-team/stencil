import { ModuleWithProviders } from '@angular/core';
/** @hidden */
export declare class CardModule {
    static forRoot(): ModuleWithProviders;
}
