import { ModuleWithProviders } from '@angular/core';
/** @hidden */
export declare class ButtonModule {
    static forRoot(): ModuleWithProviders;
}
