import { ModuleWithProviders } from '@angular/core';
/** @hidden */
export declare class LoadingModule {
    static forRoot(): ModuleWithProviders;
}
