/**
  * @hidden
  */
export declare class ItemGroup {
}
