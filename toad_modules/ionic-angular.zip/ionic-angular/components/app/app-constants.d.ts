export declare const PORTAL_DEFAULT = 1;
export declare const PORTAL_MODAL = 2;
export declare const PORTAL_LOADING = 3;
export declare const PORTAL_TOAST = 4;
