import { ModuleWithProviders } from '@angular/core';
/** @hidden */
export declare class InfiniteScrollModule {
    static forRoot(): ModuleWithProviders;
}
