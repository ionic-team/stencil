import { ModuleWithProviders } from '@angular/core';
/** @hidden */
export declare class GridModule {
    static forRoot(): ModuleWithProviders;
}
