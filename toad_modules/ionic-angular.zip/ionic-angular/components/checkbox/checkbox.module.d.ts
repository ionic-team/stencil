import { ModuleWithProviders } from '@angular/core';
/** @hidden */
export declare class CheckboxModule {
    static forRoot(): ModuleWithProviders;
}
