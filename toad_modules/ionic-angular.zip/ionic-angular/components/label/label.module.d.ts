import { ModuleWithProviders } from '@angular/core';
/** @hidden */
export declare class LabelModule {
    static forRoot(): ModuleWithProviders;
}
