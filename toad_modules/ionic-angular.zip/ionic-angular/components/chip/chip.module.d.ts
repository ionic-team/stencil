import { ModuleWithProviders } from '@angular/core';
/** @hidden */
export declare class ChipModule {
    static forRoot(): ModuleWithProviders;
}
