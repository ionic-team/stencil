import { ModuleWithProviders } from '@angular/core';
/** @hidden */
export declare class ImgModule {
    static forRoot(): ModuleWithProviders;
}
