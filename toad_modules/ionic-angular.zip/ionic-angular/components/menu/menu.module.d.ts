import { ModuleWithProviders } from '@angular/core';
/** @hidden */
export declare class MenuModule {
    static forRoot(): ModuleWithProviders;
}
