import { ModuleWithProviders } from '@angular/core';
/** @hidden */
export declare class AppModule {
    static forRoot(): ModuleWithProviders;
}
