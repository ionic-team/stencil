import { Transition } from '../../transitions/transition';
export declare class ActionSheetSlideIn extends Transition {
    init(): void;
}
export declare class ActionSheetSlideOut extends Transition {
    init(): void;
}
export declare class ActionSheetMdSlideIn extends Transition {
    init(): void;
}
export declare class ActionSheetMdSlideOut extends Transition {
    init(): void;
}
export declare class ActionSheetWpSlideIn extends Transition {
    init(): void;
}
export declare class ActionSheetWpSlideOut extends Transition {
    init(): void;
}
